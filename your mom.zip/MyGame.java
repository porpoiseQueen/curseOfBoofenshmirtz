import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.ArrayList;  
import java.awt.image.BufferedImage; 
import java.io.IOException; 
import javax.imageio.ImageIO; 
import javax.swing.JPanel; 
public class MyGame extends Game  {
    public static final String TITLE = "MyGame";
    public static final int SCREEN_WIDTH = 800;
    public static final int SCREEN_HEIGHT = 800;

    // declare variables here
	/*public static StartScreen startscreen; 
	
	public static Screen activeScreen;  */ 
	public static genericRoom g1; 
	public static genericRoom g2;
	public static StartRoom ov1; 
	public static dieScreen die; 
	public static StartScreen start; 
	public static Battle battle; 
	public static BattlePlayer player1;
	public static Screen activeScreen;  
	public BasicEnemy e1; 
	public static startHallwayScreen startHall;
	public BufferedImage image;
	public static Color myColour;
    public MyGame() {
        // initialize variables here 
		myColour = new Color(0, 0,0,0);	
		ov1=new StartRoom(); 
		die= new dieScreen(); 
		start=new StartScreen();  
		g1=new genericRoom(); 
		g2=new genericRoom();
		startHall=new startHallwayScreen();
		try{ 
			image=ImageIO.read(getClass().getResourceAsStream("/sprites/spritePaprika.png"));
		}catch (IOException e){ 
			e.printStackTrace();
		}  
		
		player1=new BattlePlayer(150,400, 100,100,myColour,10,4,30,10,1,image); 
		//e1=new BasicEnemy(600,400,100,100,myColour,10,5,5,eImage);
		activeScreen=startHall;
    }
    
    public void update() {
        // updating logic 
		
		activeScreen.update();
    }
    
    public void draw(Graphics pen) {
        
        activeScreen.draw(pen);
	
    }
        
    @Override
    public void keyTyped(KeyEvent ke) { activeScreen.keyTyped(ke);}

    @Override
    public void keyPressed(KeyEvent ke) { 
		
	}
	
    @Override
    public void keyReleased(KeyEvent ke) {activeScreen.keyReleased(ke);}
	
    @Override
    public void mouseClicked(MouseEvent me) {activeScreen.mouseClicked(me);}

    @Override
    public void mousePressed(MouseEvent me) {activeScreen.mousePressed(me);}
    
    @Override
    public void mouseReleased(MouseEvent me) {activeScreen.mouseReleased(me);}

    @Override
    public void mouseEntered(MouseEvent me) {activeScreen.mouseEntered(me);}

    @Override
    public void mouseExited(MouseEvent me) {activeScreen.mouseExited(me);}
      
	@Override 
	public void mouseDragged(MouseEvent me){activeScreen.mouseDragged(me);} 
	
	@Override 
	public void mouseMoved(MouseEvent me){activeScreen.mouseMoved(me);}
        
    //Launches the Game
    public static void main(String[] args) { new MyGame().start(TITLE, SCREEN_WIDTH,SCREEN_HEIGHT); }
}