import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
public class OvPlayer extends GameObject{ 
	public OvPlayer(int x, int y, int width, int height, Color c){ 
		super(x,y,width,height,c);
	} 
	public void update(){ 
	
	}
}