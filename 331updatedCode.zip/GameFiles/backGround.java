import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
public class backGround extends GameObject{  
	public backGround(int x, int y, int width, int height, Color c){ 
		super(x,y,width,height,c);
	} 
	public void update(){ 
	
	}
}